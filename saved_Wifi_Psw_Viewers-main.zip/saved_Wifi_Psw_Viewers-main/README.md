# saved_Wifi_Psw_Viewers
A Simple Tool to Scrape Saved Wifi Passwords on Your Linux and Windows Computers
